package exercice1;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class SpoonCouplingGraphViewer {

  
    public static File generateGraphImage(String dotPath) throws IOException, InterruptedException {
        File outputImage = new File(dotPath.replace(".dot", ".png"));

        ProcessBuilder pb = new ProcessBuilder(
                "dot", "-Tpng", dotPath, "-o", outputImage.getAbsolutePath()
        );
        pb.redirectErrorStream(true);
        Process process = pb.start();
        process.waitFor();

        if (!outputImage.exists()) {
            throw new IOException("Erreur : l'image n'a pas été générée. Vérifiez que Graphviz est installé");
        }
        return outputImage;
    }

  
    public static void displayGraph(File imageFile) {
        JFrame frame = new JFrame("Couplage entre classes (Spoon)");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        ImageIcon icon = new ImageIcon(imageFile.getAbsolutePath());
        JLabel label = new JLabel(icon);
        label.setHorizontalAlignment(SwingConstants.CENTER);

        JScrollPane scrollPane = new JScrollPane(label);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        String srcPath = "/home/imene/Downloads/CorrectionTP2_Partie1/CorrectionTP1_Partie1/CodeTD2Etape1 (7)/step1/"; 
        String outputDot = "/home/imene/Documents/coupling_graph.dot";

        try {
            SpoonCouplingGraphGenerator.generateCouplingGraph(srcPath, outputDot);
            File image = generateGraphImage(outputDot);
            displayGraph(image);

        } catch (IOException | InterruptedException e) {
            JOptionPane.showMessageDialog(null,
                    "Erreur : " + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
