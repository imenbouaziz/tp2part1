package exercice1;

import spoon.Launcher;
import spoon.reflect.CtModel;
import spoon.reflect.declaration.CtClass;
import spoon.reflect.declaration.CtType;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.visitor.filter.TypeFilter;

import java.io.*;
import java.util.*;

public class SpoonCouplingGraphGenerator {

    public static void generateCouplingGraph(String srcPath, String outputDot) throws IOException {
        //building the spoon model
        Launcher launcher = new Launcher();
        launcher.addInputResource(srcPath);
        launcher.buildModel();
        CtModel model = launcher.getModel();

        //collecting classes
        List<CtClass<?>> classes = model.getElements(new TypeFilter<>(CtClass.class));
        Set<String> classNames = new HashSet<>();
        Map<String, Map<String, Integer>> couplingCounts = new HashMap<>();
        int totalInterClassCalls = 0;

        for (CtClass<?> clazz : classes) {
            String className = clazz.getSimpleName();
            classNames.add(className);
            couplingCounts.putIfAbsent(className, new HashMap<>());

            //method invocations in a class
            List<CtInvocation<?>> invocations = clazz.getElements(new TypeFilter<>(CtInvocation.class));
            for (CtInvocation<?> inv : invocations) {
                CtTypeReference<?> targetType = inv.getExecutable().getDeclaringType();
                if (targetType == null) continue;
                String targetClass = targetType.getSimpleName();
                if (targetClass.equals(className)) continue; //no self calls I skipped them

                //counting the coupling
                Map<String, Integer> map = couplingCounts.get(className);
                map.put(targetClass, map.getOrDefault(targetClass, 0) + 1);
                totalInterClassCalls++;
            }
        }

        if (totalInterClassCalls == 0) {
            System.out.println("⚠️ Aucun appel inter-classe détecté !");
            return;
        }

        //the dot graph
        try (PrintWriter writer = new PrintWriter(new FileWriter(outputDot))) {
            writer.println("graph Couplage {");
            writer.println("  node [shape=circle, style=filled, color=lightblue];");

            //noeuds
            for (String cls : classNames) {
                writer.println("  \"" + cls + "\";");
            }

            //edges with weights
            Set<String> processedPairs = new HashSet<>();
            for (Map.Entry<String, Map<String, Integer>> entry : couplingCounts.entrySet()) {
                String c1 = entry.getKey();
                for (Map.Entry<String, Integer> target : entry.getValue().entrySet()) {
                    String c2 = target.getKey();
                    String pairKey = c1.compareTo(c2) < 0 ? c1 + "," + c2 : c2 + "," + c1;
                    if (processedPairs.contains(pairKey)) continue;
                    processedPairs.add(pairKey);

                    int count1 = target.getValue();
                    int count2 = couplingCounts.getOrDefault(c2, Collections.emptyMap()).getOrDefault(c1, 0);
                    double weight = (double) (count1 + count2) / totalInterClassCalls;
                    double penWidth = 1 + 5 * weight;

                    writer.printf("  \"%s\" -- \"%s\" [label=\"%.3f\", penwidth=%.2f];%n",
                            c1, c2, weight, penWidth);
                }
            }

            writer.println("}");
        }

        System.out.println("coupling graph generated: " + outputDot);
    }

    public static void main(String[] args) {
        String srcPath = "/home/imene/Downloads/CorrectionTP2_Partie1/CorrectionTP1_Partie1/CodeTD2Etape1 (7)/step1/";   // path to your Java source
        String outputDot = "/home/imene/Documents/coupling_graphh.dot";

        try {
            generateCouplingGraph(srcPath, outputDot);
        } catch (IOException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
    }
}
