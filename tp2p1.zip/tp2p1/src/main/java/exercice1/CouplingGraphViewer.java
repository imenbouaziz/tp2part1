package exercice1;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class CouplingGraphViewer {

    public static File generateGraphImage(String dotPath) throws IOException, InterruptedException {
        File outputImage = new File(dotPath.replace(".dot", ".png"));

        //running the Graphviz dot command
        ProcessBuilder pb = new ProcessBuilder(
                "dot", "-Tpng", dotPath, "-o", outputImage.getAbsolutePath()
        );
        pb.redirectErrorStream(true);
        Process process = pb.start();
        process.waitFor();

        if (!outputImage.exists()) {
            throw new IOException("Erreur : l'image n'a pas été générée. Assurez-vous que Graphviz est installé");
        }
        return outputImage;
    }

    //display the graph
    public static void displayGraph(File imageFile) {
        JFrame frame = new JFrame("Couplage");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        ImageIcon icon = new ImageIcon(imageFile.getAbsolutePath());
        JLabel label = new JLabel(icon);
        label.setHorizontalAlignment(SwingConstants.CENTER);

        JScrollPane scrollPane = new JScrollPane(label);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        String input = "/home/imene/Documents/TP1/Analyzer/callgraph.dot";
        String output = "/home/imene/Documents/coupling_graph.dot";

        try {
            //generating the graph
            CouplingGraphGenerator.generateCouplingGraph(input, output);

            //generating the image
            File image = generateGraphImage(output);

            //display
            displayGraph(image);

        } catch (IOException | InterruptedException e) {
            JOptionPane.showMessageDialog(null,
                    "Erreur : " + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
