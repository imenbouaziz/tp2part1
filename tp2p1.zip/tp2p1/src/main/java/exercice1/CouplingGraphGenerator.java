package exercice1;

import java.io.*;
import java.util.*;
import java.util.regex.*;

public class CouplingGraphGenerator {

    public static void generateCouplingGraph(String inputDot, String outputDot) throws IOException {
        List<String> lines = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputDot))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        }

        Pattern edgePattern = Pattern.compile("\"([^\"]+)\"\\s*->\\s*\"([^\"]+)\"");
        Map<String, Integer> pairCounts = new HashMap<>();
        Set<String> classes = new HashSet<>();
        int totalInterClass = 0;

        for (String line : lines) {
            Matcher matcher = edgePattern.matcher(line);
            if (matcher.find()) {
                String caller = matcher.group(1);
                String callee = matcher.group(2);

                String callerClass = caller.split("\\.")[0];
                String calleeClass = callee.split("\\.")[0];

                classes.add(callerClass);
                classes.add(calleeClass);

                if (!callerClass.equals(calleeClass)) {
                    totalInterClass++;

                    String key = callerClass.compareTo(calleeClass) < 0
                            ? callerClass + "," + calleeClass
                            : calleeClass + "," + callerClass;

                    pairCounts.put(key, pairCounts.getOrDefault(key, 0) + 1);
                }
            }
        }

        if (totalInterClass == 0) {
            System.out.println("aucun appel inter-classe détecté");
            return;
        }

        try (PrintWriter writer = new PrintWriter(new FileWriter(outputDot))) {
            writer.println("graph Couplage {");
            writer.println("  node [shape=circle, style=filled, color=lightgreen];");

            for (String c : classes) {
                writer.println("  \"" + c + "\";");
            }

            for (Map.Entry<String, Integer> entry : pairCounts.entrySet()) {
                String[] pair = entry.getKey().split(",");
                double weight = (double) entry.getValue() / totalInterClass;
                double penWidth = 1 + 5 * weight;

                writer.printf("  \"%s\" -- \"%s\" [label=\"%.3f\", penwidth=%.2f];%n",
                        pair[0], pair[1], weight, penWidth);
            }

            writer.println("}");
        }

        System.out.println("Graphe de couplage généré : " + outputDot);
    }

    public static void main(String[] args) {
        //change paths here 
        String input = "/home/imene/Documents/TP1/Analyzer/callgraph.dot";
        String output = "/home/imene/Documents/coupling_graph.dot";

        try {
            generateCouplingGraph(input, output);
        } catch (IOException e) {
            System.err.println("Erreur : " + e.getMessage());
        }
    }
}
