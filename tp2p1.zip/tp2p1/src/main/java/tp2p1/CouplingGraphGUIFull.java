package tp2p1;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

import exercice1.CouplingGraphViewer;
import exercice1.SpoonCouplingGraphGenerator;
import exercice1.SpoonCouplingGraphViewer;
import exercice2.HierarchicalClusteringVisualizer;
import exercice2.SpoonHierarchicalClustering;
import exercice2.SpoonModuleIdentifier;

public class CouplingGraphGUIFull {

    private JFrame frame;
    private JLabel graphLabel;
    private File callDotFile;
    private File couplingDotFile;

    private boolean useSpoon = false;
    private MaterialSwitch modeSwitch;

    public CouplingGraphGUIFull() {
        frame = new JFrame("Coupling Graph Viewer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 800);
        frame.setLayout(new BorderLayout());

        JPanel topPanel = new JPanel();
        topPanel.setBackground(Color.WHITE);
        topPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));

        JLabel switchLabel = new JLabel("Use Spoon:");
        switchLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        topPanel.add(switchLabel);

        modeSwitch = new MaterialSwitch();
        topPanel.add(modeSwitch);

        JButton selectBtn = new JButton("Select File/Folder");
        selectBtn.setFont(new Font("Arial", Font.PLAIN, 14));
        selectBtn.setBackground(new Color(33, 150, 243));
        selectBtn.setForeground(Color.WHITE);
        selectBtn.setFocusPainted(false);
        selectBtn.addActionListener(e -> selectCallGraphFileOrFolder());
        topPanel.add(selectBtn);

        frame.add(topPanel, BorderLayout.NORTH);

        graphLabel = new JLabel("", SwingConstants.CENTER);
        graphLabel.setVerticalAlignment(SwingConstants.TOP);
        JScrollPane scrollPane = new JScrollPane(graphLabel);
        frame.add(scrollPane, BorderLayout.CENTER);

        //---------------------------------------------------------------------------------
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton hierarchicalBtn = new JButton("Hierarchical Clustering");
        hierarchicalBtn.setFont(new Font("Arial", Font.PLAIN, 14));
        hierarchicalBtn.setBackground(new Color(76, 175, 80));
        hierarchicalBtn.setForeground(Color.WHITE);
        hierarchicalBtn.setFocusPainted(false);
        hierarchicalBtn.addActionListener(e -> runHierarchical());
        bottomPanel.add(hierarchicalBtn);

        JButton modulesBtn = new JButton("Identify Modules");
        modulesBtn.setFont(new Font("Arial", Font.PLAIN, 14));
        modulesBtn.setBackground(new Color(255, 152, 0));
        modulesBtn.setForeground(Color.WHITE);
        modulesBtn.setFocusPainted(false);
        modulesBtn.addActionListener(e -> runModules());
        bottomPanel.add(modulesBtn);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private void selectCallGraphFileOrFolder() {
        useSpoon = modeSwitch.isSelected();

        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(useSpoon ? JFileChooser.DIRECTORIES_ONLY : JFileChooser.FILES_ONLY);
        int ret = chooser.showOpenDialog(frame);
        if (ret == JFileChooser.APPROVE_OPTION) {
            callDotFile = chooser.getSelectedFile();

            try {
                if (useSpoon) {
                    // Spoon mode
                    couplingDotFile = new File(System.getProperty("java.io.tmpdir"), "spoon_coupling_graph.dot");
                    SpoonCouplingGraphGenerator.generateCouplingGraph(
                            callDotFile.getAbsolutePath(),
                            couplingDotFile.getAbsolutePath()
                    );
                    File image = SpoonCouplingGraphViewer.generateGraphImage(couplingDotFile.getAbsolutePath());
                    graphLabel.setIcon(new ImageIcon(image.getAbsolutePath()));
                } else {
                    // JDT mode
                    generateAndDisplayCouplingGraph();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error generating graph: " + ex.getMessage());
            }
        }
    }

    private void generateAndDisplayCouplingGraph() {
        try {
            couplingDotFile = new File(System.getProperty("java.io.tmpdir"), "coupling_graph.dot");
            exercice1.CouplingGraphGenerator.generateCouplingGraph(
                    callDotFile.getAbsolutePath(),
                    couplingDotFile.getAbsolutePath()
            );
            File image = CouplingGraphViewer.generateGraphImage(couplingDotFile.getAbsolutePath());
            graphLabel.setIcon(new ImageIcon(image.getAbsolutePath()));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
        }
    }

    private void runHierarchical() {
        if (callDotFile == null) {
            JOptionPane.showMessageDialog(frame, "Please select a file/folder first.");
            return;
        }

        try {
            if (useSpoon) {
                Map<String, Map<String, Integer>> couplings = SpoonHierarchicalClustering.computeCouplings(callDotFile.getAbsolutePath());
                Map<String, Double> flatCouplings = SpoonHierarchicalClustering.flattenCouplings(couplings);
                SpoonHierarchicalClustering.Cluster root = SpoonHierarchicalClustering.cluster(flatCouplings);

                JFrame dendroFrame = new JFrame("Dendrogram (Spoon)");
                dendroFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                dendroFrame.add(new JScrollPane(new SpoonDendrogramPanel(root)));
                dendroFrame.pack();
                dendroFrame.setLocationRelativeTo(null);
                dendroFrame.setVisible(true);

            } else {
            	//---------------------------------------------------------------------------------
                HierarchicalClusteringVisualizer.Cluster root =
                        HierarchicalClusteringVisualizer.cluster(couplingDotFile.getAbsolutePath());

                JFrame dendroFrame = new JFrame("Dendrogram (JDT)");
                dendroFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                dendroFrame.add(new JScrollPane(new HierarchicalClusteringVisualizer.DendrogramPanel(root)));
                dendroFrame.pack();
                dendroFrame.setLocationRelativeTo(null);
                dendroFrame.setVisible(true);
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Error generating dendrogram: " + ex.getMessage());
        }
    }

    private void runModules() {
        if (callDotFile == null) {
            JOptionPane.showMessageDialog(frame, "Please select a file/folder first.");
            return;
        }
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            PrintStream ps = new PrintStream(baos);
            PrintStream oldOut = System.out;
            System.setOut(ps);

            if (useSpoon) {
                Map<String, Map<String, Integer>> couplings = SpoonModuleIdentifier.computeCouplings(callDotFile.getAbsolutePath());
                Map<String, Double> flatCouplings = SpoonModuleIdentifier.flattenCouplings(couplings);
                List<SpoonModuleIdentifier.Cluster> modules = SpoonModuleIdentifier.identifyModules(
                        SpoonModuleIdentifier.buildDendrogram(flatCouplings),
                        flatCouplings,
                        0.2
                );

                System.out.println("\nIdentified modules:");
                int idx = 1;
                for (SpoonModuleIdentifier.Cluster module : modules) {
                    System.out.println("Module " + idx++ + " → " + module.elements);
                }
            } else {
                exercice2.ModuleIdentifier.main(new String[]{couplingDotFile.getAbsolutePath()});
            }

            System.out.flush();
            System.setOut(oldOut);

            JOptionPane.showMessageDialog(frame, new JScrollPane(
                    new JTextArea(baos.toString())
            ), "Module Identification Results", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
        }
    }

  //---------------------------------------------------------------------------------
    static class SpoonDendrogramPanel extends JPanel {
        private SpoonHierarchicalClustering.Cluster root;
        private Map<SpoonHierarchicalClustering.Cluster, Rectangle> positions = new HashMap<>();

        public SpoonDendrogramPanel(SpoonHierarchicalClustering.Cluster root) {
            this.root = root;
            setPreferredSize(new Dimension(800, 500));
        }

        private int drawTree(Graphics2D g, SpoonHierarchicalClustering.Cluster node, int x, int y, int spacing) {
            if (node == null) return x;

            if (node.left == null && node.right == null) {
                g.drawString(node.name, x, y);
                positions.put(node, new Rectangle(x, y, 30, 20));
                return x + spacing;
            }

            int leftX = drawTree(g, node.left, x, y + 60, spacing);
            int rightX = drawTree(g, node.right, leftX, y + 60, spacing);

            int midX = (x + rightX - spacing) / 2;
            g.drawLine(midX, y + 40, midX, y);

            Rectangle leftR = positions.get(node.left);
            Rectangle rightR = positions.get(node.right);
            g.drawLine(midX, y + 40, leftR.x + 10, leftR.y);
            g.drawLine(midX, y + 40, rightR.x + 10, rightR.y);

            positions.put(node, new Rectangle(midX, y, 30, 20));
            return rightX;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            positions.clear();
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            drawTree(g2, root, 50, 80, 100);
        }
    }

  //---------------------------------------------------------------------------------
    static class MaterialSwitch extends JComponent {
        private boolean selected = false;
        private int width = 50, height = 25;
        private Color onColor = new Color(33, 150, 243);
        private Color offColor = new Color(200, 200, 200);
        private Color knobColor = Color.WHITE;

        public MaterialSwitch() {
            setPreferredSize(new Dimension(width, height));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseClicked(java.awt.event.MouseEvent e) {
                    selected = !selected;
                    repaint();
                }
            });
        }

        public boolean isSelected() {
            return selected;
        }

        public void setSelected(boolean selected) {
            this.selected = selected;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(selected ? onColor : offColor);
            g2.fillRoundRect(0, 0, width, height, height, height);

            int knobX = selected ? width - height : 0;
            g2.setColor(knobColor);
            g2.fillOval(knobX, 0, height, height);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CouplingGraphGUIFull::new);
    }
}
