package exercice2;

import spoon.Launcher;
import spoon.reflect.declaration.*;
import spoon.reflect.reference.CtExecutableReference;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.visitor.filter.TypeFilter;

import java.util.*;

public class SpoonModuleIdentifier {

    public static class Cluster {
        String name;
        public Set<String> elements;
        Cluster left, right;

        Cluster(String name) {
            this.name = name;
            this.elements = new HashSet<>();
            this.elements.add(name);
        }

        Cluster(Cluster left, Cluster right) {
            this.left = left;
            this.right = right;
            this.elements = new HashSet<>();
            if (left != null) this.elements.addAll(left.elements);
            if (right != null) this.elements.addAll(right.elements);
            this.name = "(" + left.name + "+" + right.name + ")";
        }

        boolean isLeaf() { return left == null && right == null; }

        @Override
        public String toString() { return name; }
    }

    /** Compute class coupling map using Spoon */
    public static Map<String, Map<String, Integer>> computeCouplings(String srcPath) {
        Launcher launcher = new Launcher();
        launcher.addInputResource(srcPath);
        launcher.buildModel();

        Map<String, Map<String, Integer>> couplings = new HashMap<>();

        for (CtClass<?> clazz : launcher.getModel().getElements(new TypeFilter<>(CtClass.class))) {
            String className = clazz.getSimpleName();
            couplings.putIfAbsent(className, new HashMap<>());

            for (CtInvocation<?> inv : clazz.getElements(new TypeFilter<>(CtInvocation.class))) {
                CtExecutableReference<?> execRef = inv.getExecutable();
                CtTypeReference<?> targetType = execRef.getDeclaringType();
                if (targetType != null) {
                    String targetClass = targetType.getSimpleName();
                    if (!targetClass.equals(className)) {
                        Map<String, Integer> map = couplings.get(className);
                        map.put(targetClass, map.getOrDefault(targetClass, 0) + 1);
                    }
                }
            }
        }

        return couplings;
    }

    
    public static Map<String, Double> flattenCouplings(Map<String, Map<String, Integer>> couplings) {
        Map<String, Double> flat = new HashMap<>();
        for (String c1 : couplings.keySet()) {
            for (String c2 : couplings.get(c1).keySet()) {
                String key = c1.compareTo(c2) < 0 ? c1 + "," + c2 : c2 + "," + c1;
                flat.put(key, (double) couplings.get(c1).get(c2));
            }
        }
        return flat;
    }

   
    private static double averageIntraCoupling(Cluster cluster, Map<String, Double> couplings) {
        List<String> list = new ArrayList<>(cluster.elements);
        if (list.size() < 2) return 0.0;

        double total = 0;
        int count = 0;
        for (int i = 0; i < list.size(); i++) {
            for (int j = i + 1; j < list.size(); j++) {
                String key = list.get(i).compareTo(list.get(j)) < 0
                        ? list.get(i) + "," + list.get(j)
                        : list.get(j) + "," + list.get(i);
                if (couplings.containsKey(key)) {
                    total += couplings.get(key);
                    count++;
                }
            }
        }
        return count == 0 ? 0 : total / count;
    }

    public static Cluster buildDendrogram(Map<String, Double> couplings) {
        Set<String> allClasses = new HashSet<>();
        for (String key : couplings.keySet()) {
            String[] pair = key.split(",");
            allClasses.add(pair[0]);
            allClasses.add(pair[1]);
        }

        List<Cluster> clusters = new ArrayList<>();
        for (String c : allClasses) clusters.add(new Cluster(c));

        while (clusters.size() > 1) {
            Cluster best1 = null, best2 = null;
            double maxCoupling = -1;

            for (int i = 0; i < clusters.size(); i++) {
                for (int j = i + 1; j < clusters.size(); j++) {
                    Cluster c1 = clusters.get(i);
                    Cluster c2 = clusters.get(j);
                    double avg = averageCoupling(c1, c2, couplings);
                    if (avg > maxCoupling) {
                        maxCoupling = avg;
                        best1 = c1;
                        best2 = c2;
                    }
                }
            }

            if (best1 == null || best2 == null) break;

            Cluster merged = new Cluster(best1, best2);
            clusters.remove(best1);
            clusters.remove(best2);
            clusters.add(merged);
        }

        return clusters.get(0);
    }

   
    private static double averageCoupling(Cluster c1, Cluster c2, Map<String, Double> couplings) {
        double total = 0;
        int count = 0;
        for (String e1 : c1.elements) {
            for (String e2 : c2.elements) {
                if (e1.equals(e2)) continue;
                String key = e1.compareTo(e2) < 0 ? e1 + "," + e2 : e2 + "," + e1;
                if (couplings.containsKey(key)) {
                    total += couplings.get(key);
                    count++;
                }
            }
        }
        return count == 0 ? 0 : total / count;
    }

  
    private static void extractModules(Cluster c, Map<String, Double> couplings,
                                       double CP, int maxModules, List<Cluster> modules) {
        if (modules.size() >= maxModules) return;

        double avg = averageIntraCoupling(c, couplings);
        if (avg >= CP || c.isLeaf()) {
            modules.add(c);
        } else {
            if (c.left != null) extractModules(c.left, couplings, CP, maxModules, modules);
            if (c.right != null) extractModules(c.right, couplings, CP, maxModules, modules);
        }
    }

    //Id modules from dendrogram
    public static List<Cluster> identifyModules(Cluster root, Map<String, Double> couplings, double CP) {
        int totalClasses = root.elements.size();
        int maxModules = Math.max(1, totalClasses / 2);
        List<Cluster> modules = new ArrayList<>();
        extractModules(root, couplings, CP, maxModules, modules);
        return modules;
    }

    public static void main(String[] args) {
        String srcPath = "/home/imene/Downloads/CorrectionTP2_Partie1/CorrectionTP1_Partie1/CodeTD2Etape1 (7)/step1";
        double CP = 0.2;
        Map<String, Map<String, Integer>> couplingsMap = computeCouplings(srcPath);
       
        Set<String> classesDetected = new TreeSet<>(couplingsMap.keySet());
        System.out.println("Classes detected by Spoon:");
        for (String cls : classesDetected) {
            System.out.println(" - " + cls);
        }
        Map<String, Double> flatCouplings = flattenCouplings(couplingsMap);

        Cluster root = buildDendrogram(flatCouplings);
        List<Cluster> modules = identifyModules(root, flatCouplings, CP);

        System.out.println("\nIdentified modules:");
        for (int i = 0; i < modules.size(); i++) {
            System.out.println("Module " + (i + 1) + " → " + modules.get(i).elements);
        }
    }

}
