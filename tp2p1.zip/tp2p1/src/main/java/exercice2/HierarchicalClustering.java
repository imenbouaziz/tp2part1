package exercice2;

import java.io.*;
import java.util.*;

public class HierarchicalClustering {

    static class Cluster {
        String name;
        Set<String> elements;

        Cluster(String name) {
            this.name = name;
            this.elements = new HashSet<>();
            this.elements.add(name);
        }

        Cluster(Cluster c1, Cluster c2) {
            this.name = "(" + c1.name + "+" + c2.name + ")";
            this.elements = new HashSet<>(c1.elements);
            this.elements.addAll(c2.elements);
        }

        @Override
        public String toString() {
            return name;
        }
    }

 
    public static Cluster cluster(String couplingFile) throws IOException {
        Map<String, Double> couplings = new HashMap<>();
        Set<String> allClasses = new HashSet<>();

        //loading edges
        try (BufferedReader br = new BufferedReader(new FileReader(couplingFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("--")) {
                    String[] parts = line.split("--");
                    String c1 = parts[0].replaceAll("[^a-zA-Z0-9_]", "");
                    String c2 = parts[1].split("\\[")[0].replaceAll("[^a-zA-Z0-9_]", "");
                    String weightStr = line.replaceAll(".*label=\"([0-9.]+)\".*", "$1");

                    try {
                        double weight = Double.parseDouble(weightStr);
                        String key = c1.compareTo(c2) < 0 ? c1 + "," + c2 : c2 + "," + c1;
                        couplings.put(key, weight);
                        allClasses.add(c1);
                        allClasses.add(c2);
                    } catch (Exception ignored) {}
                }
            }
        }

        //init clusters
        List<Cluster> clusters = new ArrayList<>();
        for (String c : allClasses) {
            clusters.add(new Cluster(c));
        }

        System.out.println("Initial clusters: " + clusters);

        //hierarchical clustering
        while (clusters.size() > 1) {
            Cluster best1 = null, best2 = null;
            double maxCoupling = -1;

            //2 most coupled clusters
            for (int i = 0; i < clusters.size(); i++) {
                for (int j = i + 1; j < clusters.size(); j++) {
                    Cluster c1 = clusters.get(i);
                    Cluster c2 = clusters.get(j);
                    double coupling = averageCoupling(c1, c2, couplings);
                    if (coupling > maxCoupling) {
                        maxCoupling = coupling;
                        best1 = c1;
                        best2 = c2;
                    }
                }
            }

            if (best1 == null || best2 == null) break;

            Cluster merged = new Cluster(best1, best2);
            clusters.remove(best1);
            clusters.remove(best2);
            clusters.add(merged);

            System.out.printf("Merged %s and %s -> %s (coupling=%.3f)%n",
                    best1, best2, merged, maxCoupling);
        }

        System.out.println("\n final dendrogram: " + clusters.get(0));
		return null;
    }

    private static double averageCoupling(Cluster c1, Cluster c2, Map<String, Double> couplings) {
        double total = 0;
        int count = 0;

        for (String e1 : c1.elements) {
            for (String e2 : c2.elements) {
                String key = e1.compareTo(e2) < 0 ? e1 + "," + e2 : e2 + "," + e1;
                if (couplings.containsKey(key)) {
                    total += couplings.get(key);
                    count++;
                }
            }
        }

        return count == 0 ? 0 : total / count;
    }

    public static void main(String[] args) throws IOException {
        String couplingFile = "/home/imene/Documents/coupling_graph.dot";
        cluster(couplingFile);
    }
}
