package exercice2;

import spoon.Launcher;
import spoon.reflect.declaration.*;
import spoon.reflect.reference.CtExecutableReference;
import spoon.reflect.reference.CtTypeReference;
import spoon.reflect.code.CtInvocation;
import spoon.reflect.visitor.filter.TypeFilter;

import java.util.*;

public class SpoonHierarchicalClustering {

    public static class Cluster {
        public String name;
        public Set<String> elements;
        public Cluster left;
		public Cluster right;

        Cluster(String name) {
            this.name = name;
            this.elements = new HashSet<>();
            this.elements.add(name);
        }

        Cluster(Cluster c1, Cluster c2) {
            this.left = c1;
            this.right = c2;
            this.elements = new HashSet<>(c1.elements);
            this.elements.addAll(c2.elements);
            this.name = "(" + c1.name + "+" + c2.name + ")";
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public static Map<String, Map<String, Integer>> computeCouplings(String srcPath) {
        Launcher launcher = new Launcher();
        launcher.addInputResource(srcPath);
        launcher.buildModel();

        Map<String, Map<String, Integer>> couplings = new HashMap<>();

        for (CtClass<?> clazz : launcher.getModel().getElements(new TypeFilter<>(CtClass.class))) {
            String className = clazz.getSimpleName();
            couplings.putIfAbsent(className, new HashMap<>());

            for (CtInvocation<?> inv : clazz.getElements(new TypeFilter<>(CtInvocation.class))) {
                CtExecutableReference<?> execRef = inv.getExecutable();
                CtTypeReference<?> targetType = execRef.getDeclaringType();

                if (targetType != null) {
                    String targetClass = targetType.getSimpleName();
                    if (!targetClass.equals(className)) {
                        Map<String, Integer> map = couplings.get(className);
                        map.put(targetClass, map.getOrDefault(targetClass, 0) + 1);
                    }
                }
            }
        }

        return couplings;
    }

    //Flattening to weighted edges
    public static Map<String, Double> flattenCouplings(Map<String, Map<String, Integer>> couplings) {
        Map<String, Double> flat = new HashMap<>();
        for (String c1 : couplings.keySet()) {
            for (String c2 : couplings.get(c1).keySet()) {
                String key = c1.compareTo(c2) < 0 ? c1 + "," + c2 : c2 + "," + c1;
                flat.put(key, (double) couplings.get(c1).get(c2));
            }
        }
        return flat;
    }

    //avg coupling
    private static double averageCoupling(Cluster c1, Cluster c2, Map<String, Double> couplings) {
        double total = 0;
        int count = 0;

        for (String e1 : c1.elements) {
            for (String e2 : c2.elements) {
                String key = e1.compareTo(e2) < 0 ? e1 + "," + e2 : e2 + "," + e1;
                if (couplings.containsKey(key)) {
                    total += couplings.get(key);
                    count++;
                }
            }
        }
        return count == 0 ? 0 : total / count;
    }

    //hierarchical clustering
    public static Cluster cluster(Map<String, Double> couplings) {
        List<Cluster> clusters = new ArrayList<>();
        Set<String> allClasses = new HashSet<>();
        for (String k : couplings.keySet()) {
            String[] pair = k.split(",");
            allClasses.add(pair[0]);
            allClasses.add(pair[1]);
        }
        for (String c : allClasses) clusters.add(new Cluster(c));

        while (clusters.size() > 1) {
            Cluster best1 = null, best2 = null;
            double maxCoupling = -1;

            for (int i = 0; i < clusters.size(); i++) {
                for (int j = i + 1; j < clusters.size(); j++) {
                    double avg = averageCoupling(clusters.get(i), clusters.get(j), couplings);
                    if (avg > maxCoupling) {
                        maxCoupling = avg;
                        best1 = clusters.get(i);
                        best2 = clusters.get(j);
                    }
                }
            }

            if (best1 == null || best2 == null) break;

            Cluster merged = new Cluster(best1, best2);
            clusters.remove(best1);
            clusters.remove(best2);
            clusters.add(merged);

            System.out.printf("Merged %s + %s -> %s (avg coupling=%.3f)%n", best1, best2, merged, maxCoupling);
        }

        return clusters.get(0);
    }

    public static void main(String[] args) {
        String srcPath = "/home/imene/Downloads/CorrectionTP2_Partie1/CorrectionTP1_Partie1/CodeTD2Etape1 (7)/step1"; 

        Map<String, Map<String, Integer>> couplings = computeCouplings(srcPath);
        Map<String, Double> flatCouplings = flattenCouplings(couplings);

        System.out.println("Flat coupling weights: " + flatCouplings);

        Cluster root = cluster(flatCouplings);
        System.out.println("\n final dendrogram: " + root);
    }
}
