package exercice2;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;

public class HierarchicalClusteringVisualizer {

    public static class Cluster {
        String name;
        Set<String> elements;
        Cluster left, right;
        double coupling;

        Cluster(String name) {
            this.name = name;
            this.elements = new HashSet<>();
            this.elements.add(name);
        }

        Cluster(Cluster c1, Cluster c2, double coupling) {
            this.name = "(" + c1.name + "+" + c2.name + ")";
            this.elements = new HashSet<>(c1.elements);
            this.elements.addAll(c2.elements);
            this.left = c1;
            this.right = c2;
            this.coupling = coupling;
        }

        boolean isLeaf() {
            return left == null && right == null;
        }
    }
    private static Map<String, Double> loadCouplings(String filePath) throws IOException {
        Map<String, Double> couplings = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.contains("--")) {
                    String[] parts = line.split("--");
                    String c1 = parts[0].replaceAll("[^a-zA-Z0-9_]", "");
                    String c2 = parts[1].split("\\[")[0].replaceAll("[^a-zA-Z0-9_]", "");
                    String weightStr = line.replaceAll(".*label=\"([0-9.]+)\".*", "$1");
                    try {
                        double weight = Double.parseDouble(weightStr);
                        String key = c1.compareTo(c2) < 0 ? c1 + "," + c2 : c2 + "," + c1;
                        couplings.put(key, weight);
                    } catch (Exception ignored) {}
                }
            }
        }
        return couplings;
    }

    private static double averageCoupling(Cluster c1, Cluster c2, Map<String, Double> couplings) {
        double total = 0;
        int count = 0;
        for (String e1 : c1.elements) {
            for (String e2 : c2.elements) {
                String key = e1.compareTo(e2) < 0 ? e1 + "," + e2 : e2 + "," + e1;
                if (couplings.containsKey(key)) {
                    total += couplings.get(key);
                    count++;
                }
            }
        }
        return count == 0 ? 0 : total / count;
    }

    //hierarchical clustering
    public static Cluster cluster(String filePath) throws IOException {
        Map<String, Double> couplings = loadCouplings(filePath);
        Set<String> allClasses = new HashSet<>();
        for (String key : couplings.keySet()) {
            String[] parts = key.split(",");
            allClasses.add(parts[0]);
            allClasses.add(parts[1]);
        }

        java.util.List<Cluster> clusters = new java.util.ArrayList<>();

        for (String c : allClasses) clusters.add(new Cluster(c));

        while (clusters.size() > 1) {
            Cluster best1 = null, best2 = null;
            double maxCoupling = -1;

            for (int i = 0; i < clusters.size(); i++) {
                for (int j = i + 1; j < clusters.size(); j++) {
                    double coupling = averageCoupling(clusters.get(i), clusters.get(j), couplings);
                    if (coupling > maxCoupling) {
                        maxCoupling = coupling;
                        best1 = clusters.get(i);
                        best2 = clusters.get(j);
                    }
                }
            }

            if (best1 == null || best2 == null) break;

            Cluster merged = new Cluster(best1, best2, maxCoupling);
            clusters.remove(best1);
            clusters.remove(best2);
            clusters.add(merged);
        }

        return clusters.get(0);
    }

    //--------------------------------------------------------------------------------------
    public static class DendrogramPanel extends JPanel {
        Cluster root;
        Map<Cluster, Rectangle> positions = new HashMap<>();

        public DendrogramPanel(Cluster root) {
            this.root = root;
            setPreferredSize(new Dimension(800, 500));
        }

        private int drawTree(Graphics2D g, Cluster node, int x, int y, int spacing) {
            if (node == null) return x;

            if (node.isLeaf()) {
                g.drawString(node.name, x, y);
                positions.put(node, new Rectangle(x, y, 30, 20));
                return x + spacing;
            }

            int leftX = drawTree(g, node.left, x, y + 60, spacing);
            int rightX = drawTree(g, node.right, leftX, y + 60, spacing);

            int midX = (x + rightX - spacing) / 2;
            g.drawLine(midX, y + 40, midX, y);
            g.drawString(String.format("%.2f", node.coupling), midX - 10, y - 5);

            Rectangle leftR = positions.get(node.left);
            Rectangle rightR = positions.get(node.right);
            g.drawLine(midX, y + 40, leftR.x + 10, leftR.y);
            g.drawLine(midX, y + 40, rightR.x + 10, rightR.y);

            positions.put(node, new Rectangle(midX, y, 30, 20));
            return rightX;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            positions.clear();
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            drawTree(g2, root, 50, 80, 100);
        }
    }

    //-----------------------------------------------------------------------------------------------
    public static void main(String[] args) throws Exception {
        String couplingFile = "/home/imene/Documents/coupling_graph.dot";
        Cluster root = cluster(couplingFile);

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Dendrogramme de Clustering Hiérarchique");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(new JScrollPane(new DendrogramPanel(root)));
            frame.pack();
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
